<?php
/**
 * Title: Contact Page 
 * Slug: elitegrove/contact-page
 * Categories: elitegrove
 * Post Types: page, wp_template
 * Keywords: contact
 */
?>
<!-- wp:pattern {"slug":"elitegrove/contact"} /-->
<!-- wp:pattern {"slug":"elitegrove/cta"} /-->