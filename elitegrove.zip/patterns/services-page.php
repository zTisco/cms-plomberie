<?php
/**
 * Title: Services Page 
 * Slug: elitegrove/services-page
 * Categories: elitegrove
 * Post Types: page, wp_template
 * Keywords: services
 */
?>
<!-- wp:pattern {"slug":"elitegrove/services"} /-->
<!-- wp:pattern {"slug":"elitegrove/testimonials"} /-->
<!-- wp:pattern {"slug":"elitegrove/faq"} /-->
<!-- wp:pattern {"slug":"elitegrove/cta"} /-->