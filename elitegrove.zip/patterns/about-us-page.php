<?php
/**
 * Title: About Us Page 
 * Slug: elitegrove/about-us-page
 * Categories: elitegrove
 * Post Types: page, wp_template
 * Keywords: about-us
 */
?>
<!-- wp:pattern {"slug":"elitegrove/about-us"} /-->
<!-- wp:pattern {"slug":"elitegrove/team"} /-->
<!-- wp:pattern {"slug":"elitegrove/latest-posts"} /-->