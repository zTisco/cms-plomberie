<?php
/**
 * Title: Product
 * Slug: home-decoration-shop/about-us
 * Categories: about-us
 * Block Types: core/template-part/about-us
 */
?>

<!-- wp:group {"tagName":"main","style":{"typography":{"fontStyle":"normal","fontWeight":"800"},"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"blockGap":"0"},"color":{"background":"#130e07"}},"className":"wp-block-cover__background","layout":{"type":"constrained","contentSize":"70%"}} -->
<main class="wp-block-group wp-block-cover__background has-background" style="background-color:#130e07;margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;font-style:normal;font-weight:800"><!-- wp:spacer {"height":"25px"} -->
<div style="height:25px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<<!-- wp:columns {"verticalAlignment":"center","className":"product-main"} -->
<div class="wp-block-columns are-vertically-aligned-center product-main"><!-- wp:column {"verticalAlignment":"center","width":"50%","className":"about-text-box"} -->
<div class="wp-block-column is-vertically-aligned-center about-text-box" style="flex-basis:50%"><!-- wp:heading {"textAlign":"center","level":6,"style":{"color":{"text":"#bd8e4a"},"elements":{"link":{"color":{"text":"#bd8e4a"}}},"typography":{"fontStyle":"normal","fontWeight":"700","fontSize":"15px"}},"backgroundColor":"contrast","className":"short-heading","fontFamily":"nunito"} -->
<h6 class="wp-block-heading has-text-align-center short-heading has-contrast-background-color has-text-color has-background has-link-color has-nunito-font-family" style="color:#bd8e4a;font-size:15px;font-style:normal;font-weight:700"><?php echo esc_html('Our Achievements','home-decoration-shop'); ?></h6>
<!-- /wp:heading -->

<!-- wp:heading {"level":3,"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"typography":{"fontSize":"35px","fontStyle":"normal","fontWeight":"900"}},"textColor":"base","fontFamily":"nunito"} -->
<h3 class="wp-block-heading has-base-color has-text-color has-link-color has-nunito-font-family" style="font-size:35px;font-style:normal;font-weight:900"><?php echo esc_html('We Commit to Big Ideas','home-decoration-shop'); ?><br><?php echo esc_html('and Services','home-decoration-shop'); ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px","fontStyle":"normal","fontWeight":"600"},"color":{"text":"#8c93a6"},"elements":{"link":{"color":{"text":"#8c93a6"}}}},"fontFamily":"nunito"} -->
<p class="has-text-color has-link-color has-nunito-font-family" style="color:#8c93a6;font-size:15px;font-style:normal;font-weight:600"><?php echo esc_html('Maecenas elementum tortor vel sem ullamcorper tristique. Mauris aliquam volutpat velit aliquam suscipit. Morbi sed eleifend libero, vitae egestas dui. Maecenas id orci et libero blandit faucibus.','home-decoration-shop'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"var:preset|spacing|30","right":"var:preset|spacing|30"},"blockGap":"0"},"border":{"width":"0px","style":"none"}},"backgroundColor":"contrast","className":"counter-box"} -->
<div class="wp-block-column counter-box has-contrast-background-color has-background" style="border-style:none;border-width:0px;padding-top:0;padding-right:var(--wp--preset--spacing--30);padding-bottom:0;padding-left:var(--wp--preset--spacing--30)"><!-- wp:heading {"textAlign":"center","level":3,"style":{"color":{"text":"#bd8e4a"},"elements":{"link":{"color":{"text":"#bd8e4a"}}},"typography":{"fontStyle":"normal","fontWeight":"900","fontSize":"45px"},"spacing":{"padding":{"top":"var:preset|spacing|30","bottom":"0"}}},"fontFamily":"nunito"} -->
<h3 class="wp-block-heading has-text-align-center has-text-color has-link-color has-nunito-font-family" style="color:#bd8e4a;padding-top:var(--wp--preset--spacing--30);padding-bottom:0;font-size:45px;font-style:normal;font-weight:900"><?php echo esc_html('26','home-decoration-shop'); ?></h3>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"center","level":6,"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"typography":{"fontSize":"15px","textTransform":"capitalize"},"spacing":{"padding":{"right":"0","left":"0","top":"0","bottom":"var:preset|spacing|30"}}},"textColor":"base","fontFamily":"nunito"} -->
<h6 class="wp-block-heading has-text-align-center has-base-color has-text-color has-link-color has-nunito-font-family" style="padding-top:0;padding-right:0;padding-bottom:var(--wp--preset--spacing--30);padding-left:0;font-size:15px;text-transform:capitalize"><?php echo esc_html('Years','home-decoration-shop'); ?><br><?php echo esc_html('Experiences','home-decoration-shop'); ?></h6>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"right":"var:preset|spacing|30","left":"var:preset|spacing|30"},"blockGap":"0"}},"backgroundColor":"contrast","className":"counter-box"} -->
<div class="wp-block-column counter-box has-contrast-background-color has-background" style="padding-right:var(--wp--preset--spacing--30);padding-left:var(--wp--preset--spacing--30)"><!-- wp:heading {"textAlign":"center","level":3,"style":{"color":{"text":"#bd8e4a"},"elements":{"link":{"color":{"text":"#bd8e4a"}}},"typography":{"fontStyle":"normal","fontWeight":"900","fontSize":"45px"},"spacing":{"padding":{"top":"var:preset|spacing|30"}}},"fontFamily":"nunito"} -->
<h3 class="wp-block-heading has-text-align-center has-text-color has-link-color has-nunito-font-family" style="color:#bd8e4a;padding-top:var(--wp--preset--spacing--30);font-size:45px;font-style:normal;font-weight:900"><?php echo esc_html('120','home-decoration-shop'); ?></h3>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"center","level":6,"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"typography":{"fontStyle":"normal","fontWeight":"600","fontSize":"15px","textTransform":"capitalize"},"spacing":{"padding":{"bottom":"var:preset|spacing|30"}}},"textColor":"base","fontFamily":"nunito"} -->
<h6 class="wp-block-heading has-text-align-center has-base-color has-text-color has-link-color has-nunito-font-family" style="padding-bottom:var(--wp--preset--spacing--30);font-size:15px;font-style:normal;font-weight:600;text-transform:capitalize"><?php echo esc_html('Commercial','home-decoration-shop'); ?> &amp; <?php echo esc_html('Public Space','home-decoration-shop'); ?></h6>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"blockGap":"0","padding":{"right":"var:preset|spacing|30","left":"var:preset|spacing|30"}}},"backgroundColor":"contrast","className":"counter-box"} -->
<div class="wp-block-column counter-box has-contrast-background-color has-background" style="padding-right:var(--wp--preset--spacing--30);padding-left:var(--wp--preset--spacing--30)"><!-- wp:heading {"textAlign":"center","level":3,"style":{"color":{"text":"#bd8e4a"},"elements":{"link":{"color":{"text":"#bd8e4a"}}},"typography":{"fontStyle":"normal","fontWeight":"900","fontSize":"45px"},"spacing":{"padding":{"top":"var:preset|spacing|30"}}},"fontFamily":"nunito"} -->
<h3 class="wp-block-heading has-text-align-center has-text-color has-link-color has-nunito-font-family" style="color:#bd8e4a;padding-top:var(--wp--preset--spacing--30);font-size:45px;font-style:normal;font-weight:900"><?php echo esc_html('16','home-decoration-shop'); ?></h3>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"center","level":6,"style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"typography":{"fontStyle":"normal","fontWeight":"600","fontSize":"15px","textTransform":"capitalize"},"spacing":{"padding":{"bottom":"var:preset|spacing|30"}}},"textColor":"base","fontFamily":"nunito"} -->
<h6 class="wp-block-heading has-text-align-center has-base-color has-text-color has-link-color has-nunito-font-family" style="padding-bottom:var(--wp--preset--spacing--30);font-size:15px;font-style:normal;font-weight:600;text-transform:capitalize"><?php echo esc_html('Industry Awards Won','home-decoration-shop'); ?></h6>
<!-- /wp:heading --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"50%","className":"about-image-box"} -->
<div class="wp-block-column is-vertically-aligned-center about-image-box" style="flex-basis:50%"><!-- wp:image {"id":106,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url(get_template_directory_uri()) ?>/assets/images/about-image.png" alt="" class="wp-image-106"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"25px"} -->
<div style="height:25px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer --></main>
<!-- /wp:group -->