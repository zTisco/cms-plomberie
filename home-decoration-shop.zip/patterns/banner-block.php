<?php
/**
 * Title: Banner Block
 * Slug: home-decoration-shop/banner-block
 * Categories: banner
 * Block Types: core/template-part/banner
 */
?>

<!-- wp:group {"style":{"spacing":{"padding":{"right":"0","left":"0","top":"0","bottom":"0"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained","contentSize":"100%"}} -->
<div class="wp-block-group" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}},"color":{"background":"#130e07"}},"className":"wow fadeInLeft","layout":{"type":"constrained","contentSize":"100%"}} -->
<div class="wp-block-group wow fadeInLeft has-background" style="background-color:#130e07;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:columns {"verticalAlignment":"center","align":"wide","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"className":"slider-banner"} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center slider-banner" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:column {"verticalAlignment":"center","width":"45%","className":"banner-main"} -->
<div class="wp-block-column is-vertically-aligned-center banner-main" style="flex-basis:45%"><!-- wp:image {"id":87,"style":{"color":{}},"className":"slider-img"} -->
<figure class="wp-block-image slider-img"><img src="<?php echo esc_url(get_template_directory_uri()) ?>/assets/images/slider-image.png" alt="" class="wp-image-87"/></figure>
<!-- /wp:image -->

<!-- wp:image {"lightbox":{"enabled":false},"id":66,"sizeSlug":"full","linkDestination":"custom","className":"slide-img"} -->
<figure class="wp-block-image size-full slide-img"><a href="#"><img src="<?php echo esc_url(get_template_directory_uri()) ?>/assets/images/video.png" alt="" class="wp-image-66"/></a></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"55%","className":"slider-content"} -->
<div class="wp-block-column is-vertically-aligned-center slider-content" style="flex-basis:55%"><!-- wp:heading {"style":{"typography":{"textTransform":"capitalize","fontSize":"40px","fontStyle":"normal","fontWeight":"900"},"spacing":{"margin":{"right":"0","left":"0","top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}},"textColor":"base","className":"is-slide-heading","fontFamily":"nunito"} -->
<h2 class="wp-block-heading is-slide-heading has-base-color has-text-color has-nunito-font-family" style="margin-top:var(--wp--preset--spacing--30);margin-right:0;margin-bottom:var(--wp--preset--spacing--30);margin-left:0;font-size:40px;font-style:normal;font-weight:900;text-transform:capitalize"><strong><?php echo esc_html('Discover Architectural','home-decoration-shop'); ?></strong><br><strong><?php echo esc_html('Excellence Unveiling','home-decoration-shop'); ?> </strong><br><strong><?php echo esc_html('Innovative Designs','home-decoration-shop'); ?></strong></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"#8c93a6"}}},"color":{"text":"#8c93a6"}}} -->
<p class="has-text-color has-link-color" style="color:#8c93a6"><?php echo esc_html('We Specialize in Growing Your Company, No','home-decoration-shop'); ?> <br><?php echo esc_html('Matter How Small the Start.','home-decoration-shop'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:buttons {"className":"slide-btn"} -->
<div class="wp-block-buttons slide-btn"><!-- wp:button {"textColor":"base","style":{"color":{"background":"#bd8e4a"},"spacing":{"padding":{"left":"30px","right":"30px","top":"6px","bottom":"6px"}},"typography":{"fontStyle":"normal","fontWeight":"700","textTransform":"capitalize","fontSize":"18px"}},"className":"theme-btn","fontFamily":"nunito"} -->
<div class="wp-block-button has-custom-font-size theme-btn has-nunito-font-family" style="font-size:18px;font-style:normal;font-weight:700;text-transform:capitalize"><a class="wp-block-button__link has-base-color has-text-color has-background wp-element-button" href="#" style="background-color:#bd8e4a;padding-top:6px;padding-right:30px;padding-bottom:6px;padding-left:30px"><?php echo esc_html('Get Started','home-decoration-shop'); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->