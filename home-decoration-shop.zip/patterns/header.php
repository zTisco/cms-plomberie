<?php
/**
 * Title: Header
 * Slug: home-decoration-shop/header
 * Categories: header
 * Block Types: core/template-part/header
 */
?>

<!-- wp:group {"style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"top":"20px","bottom":"20px"}}},"backgroundColor":"contrast","className":"main-header","layout":{"type":"constrained","contentSize":"70%"}} -->
<div class="wp-block-group main-header has-contrast-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:20px;padding-bottom:20px"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"top","width":"43%","style":{"spacing":{"blockGap":"0"}},"className":"logo-box"} -->
<div class="wp-block-column is-vertically-aligned-top logo-box" style="flex-basis:43%"><!-- wp:site-title {"textAlign":"left","style":{"elements":{"link":{"color":{"text":"var:preset|color|base"}}},"typography":{"textTransform":"capitalize","fontStyle":"normal","fontWeight":"600"}},"textColor":"base","fontSize":"large","fontFamily":"roboto-flex"} /--></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"57%","className":"menu-box"} -->
<div class="wp-block-column is-vertically-aligned-center menu-box" style="flex-basis:57%"><!-- wp:navigation {"textColor":"base","className":"is-head-menu","layout":{"type":"flex","justifyContent":"left"},"style":{"typography":{"fontStyle":"normal","fontWeight":"600"}},"fontSize":"medium","fontFamily":"nunito"} -->
<!-- wp:navigation-link {"label":"Home","type":"","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- wp:navigation-link {"label":"Projects","type":"","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- wp:navigation-link {"label":"Services","type":"","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- wp:navigation-link {"label":"About Us","type":"","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- wp:navigation-link {"label":"Blogs","type":"","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- wp:navigation-link {"label":"Contact","type":"","url":"#","kind":"custom","isTopLevelLink":true} /-->
<!-- /wp:navigation --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->