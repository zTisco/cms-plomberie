=== Home Decoration Shop ===
Contributors: titanthemes
Requires at least: 6.1
Tested up to: 6.6
Requires PHP: 7.2
Stable tag: 1.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Home Decoration Shop is a beautifully designed and highly functional WordPress theme tailored for home decor stores and shops selling home accessories and furnishings. Its sleek and modern layout is both visually appealing and user-friendly, ensuring an engaging shopping experience for visitors. This theme is ideal for showcasing a wide range of products, including decorative items, wall art, wall decor, picture frames, mirrors, rugs, carpets, curtains, blinds, and throw pillows.The theme’s design emphasizes elegance and simplicity, featuring clean lines and a well-organized layout that highlights your products in the best possible light. High-resolution images and customizable galleries allow you to present items like bedding, bedspreads, comforters, duvet covers, table linens, tablecloths, placemats, and table runners in stunning detail.The responsive design ensures that your website looks great on all devices, from desktops to mobile phones. With a focus on versatility, the Home Decoration Shop theme supports a variety of product categories such as lighting, candles, candle holders, vases, flower arrangements, artificial flowers, and indoor plants. It also accommodates decorative storage solutions, including storage boxes, baskets, wall shelves, floating shelves, decorative shelves, and bookshelves.Additional features include product filters, search functionality, customer reviews, shopping cart integration, and secure checkout. The theme also supports SEO optimization, social media integration, and email marketing, enhancing your online presence and driving sales. This comprehensive theme provides everything you need to create a stunning online presence for your home decor business, enhancing customer engagement and driving sales.

== Changelog ==

= 1.6 =
* Added footer Oct 15, 2024
* Done inner page setting Oct 15, 2024

= 1.5 =
* Done the minor changes: Sept 24, 2024

= 1.4 =
* Updated lite doc in get-started: August 06, 2024
* Added sidebar: August 06, 2024
* Updated WordPress version: August 06, 2024
* Updated Archive Page layout: August 06, 2024

= 1.3 =
* Updated get-started: July 19, 2024
* Remove style variation: July 19, 2024

= 1.2 =
* Added notice function: July 04, 2024
* Added about-theme details: July 04, 2024
* Updated PHP versions: July 04, 2024

= 1.1 =
* Resolved issues.

= 1.0 =
* Released: June 25, 2024

== Copyright ==

Home Decoration Shop WordPress Theme, (C) 2022-2024 Titan Themes
Home Decoration Shop is distributed under the terms of the GNU GPL.

Home Decoration Shop WordPress Theme incorporates code from Twenty Twenty-Three WordPress Theme, Copyright 2022-2024 WordPress.org
Twenty Twenty-Three WordPress Theme is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/644011

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1148865

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/782117


Google Web Fonts ( Barlow+Condensed, Sofia+Sans+Semi+Condensed, Inter, Oswald, Roboto+Flex, Nunito) By Google - https://google.com

* Barlow+Condensed, https://fonts.google.com/specimen/Barlow+Condensed?query=Barlow+Condensed

* Sofia+Sans+Semi+Condensed, This is the normal family, Licensed under Open Font License, https://fonts.google.com/specimen/Sofia+Sans+Semi+Condensed?query=sofia+sans+semi+condensed

* Inter, This is the normal family, Licensed under Open Font License, https://fonts.google.com/specimen/Inter?query=inter

* Oswald, This is the normal family, Licensed under Open Font License, https://fonts.google.com/specimen/Oswald?query=Oswald

* Roboto+Flex, This is the normal family, Licensed under Open Font License, https://fonts.google.com/specimen/Roboto+Flex?query=+Roboto+Flex

* Nunito, This is the normal family, Licensed under Open Font License, https://fonts.google.com/specimen/Nunito?query=Nunito