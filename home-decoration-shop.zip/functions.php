<?php
/**
 * Home Decoration Shop functions
 */

if ( ! function_exists( 'home_decoration_shop_setup' ) ) :
function home_decoration_shop_setup() {

    load_theme_textdomain( 'home-decoration-shop', get_template_directory() . '/languages' );	
}
endif; 
add_action( 'after_setup_theme', 'home_decoration_shop_setup' );

if ( ! function_exists( 'home_decoration_shop_styles' ) ) :
	function home_decoration_shop_styles() {
		// Register theme stylesheet.
		wp_register_style('home-decoration-shop-style',
			get_template_directory_uri() . '/style.css',array(),
			wp_get_theme()->get( 'Version' )
		);

		// Enqueue theme stylesheet.
		wp_enqueue_style( 'home-decoration-shop-style' );
	}
endif;
add_action( 'wp_enqueue_scripts', 'home_decoration_shop_styles' );

/**
 * About Theme Function
 */
require get_theme_file_path( '/about-theme/about-theme.php' );